import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        HashMap<Book, LinkedList<Member>> libraryMap = new HashMap<>();

        // Create books
        Book book1 = new Book("1984", "George Orwell");
        Book book2 = new Book("The warrios's apprentice", "Lois McMaster Bujold");
        Book book3 = new Book("Elantris", "Brandon Sanderson");

        // Create members
        Member member1 = new Member("Alice", 101);
        Member member2 = new Member("Bob", 102);
        Member member3 = new Member("Charlie", 103);
        Member member4 = new Member("Dave", 104);
        Member member5 = new Member("Eve", 105);
        Member member6 = new Member("Frank", 106);

        // Add members to books
        LinkedList<Member> members1 = new LinkedList<>();
        members1.add(member1);
        members1.add(member2);
        libraryMap.put(book1, members1);

        LinkedList<Member> members2 = new LinkedList<>();
        members2.add(member3);
        members2.add(member4);
        libraryMap.put(book2, members2);

        LinkedList<Member> members3 = new LinkedList<>();
        members3.add(member5);
        members3.add(member6);
        libraryMap.put(book3, members3);

        // Iterate through the HashMap and display books with their members
        for (Map.Entry<Book, LinkedList<Member>> entry : libraryMap.entrySet()) {
            System.out.println("Book: " + entry.getKey());
            System.out.println("Members: " + entry.getValue());
            System.out.println();
        }
    }
}
