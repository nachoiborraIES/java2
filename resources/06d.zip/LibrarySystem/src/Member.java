class Member {
    String name;
    int memberID;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
    }

    @Override
    public String toString() {
        return name + " (ID: " + memberID + ")";
    }
}
