package animalconversation;

public class Main 
{
    public static void main(String[] args) 
    {
        Dog d = new Dog("Bobby");
        Cat c = new Cat("Figaro");
        Sheep s = new Sheep("Dolly");
        
        AnimalConversation<Dog, Cat> ac1 = new AnimalConversation<>(d, c);
        AnimalConversation<Cat, Sheep> ac2 = new AnimalConversation<>(c, s);
        //ERROR: AnimalConversation<Dog, Sheep> ac3 = new AnimalConversation<>(c, d);
        
        ac1.chat();
        ac2.chat();
    }
}
