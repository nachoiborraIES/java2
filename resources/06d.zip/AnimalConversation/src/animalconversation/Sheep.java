package animalconversation;

public class Sheep extends Animal
{    
    public Sheep(String name)
    {
        super(name);
    }
    
    @Override
    public String talk()
    {
        return "Beee";
    }
}
