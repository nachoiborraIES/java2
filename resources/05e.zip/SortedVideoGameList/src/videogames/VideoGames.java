package videogames;

import java.util.Arrays;
import videogames.data.PCVideoGame;
import videogames.data.VideoGame;

public class VideoGames 
{
    public static final int MAX_VIDEOGAMES = 5;
    
    public static void main(String[] args)
    {
        VideoGame[] games = new VideoGame[MAX_VIDEOGAMES];
        
        games[0] = new VideoGame("Mario Kart", "Sport", 25);
        games[1] = new PCVideoGame(1, 600, "Call of Duty", "Shooter", 19);
        games[2] = new PCVideoGame(2, 900, "Fifa 17", "Sports", 30);
        games[3] = new VideoGame("Kingdom Hearts", "Adventure", 30);
        games[4] = new VideoGame("Heavy Rain", "Adventure", 50);

        // Sort with Comparable (prices in ascending order)

        Arrays.sort(games);

        System.out.println("Games sorted by price (descending):");

        for (VideoGame g: games)
        {
            System.out.println(g);
        }

        // Sort with Comparator (titles in ascending order)

        Arrays.sort(games, new VideoGameComparator());

        System.out.println("Games sorted by title (ascending):");

        for (VideoGame g: games)
        {
            System.out.println(g);
        }
    }    
}
