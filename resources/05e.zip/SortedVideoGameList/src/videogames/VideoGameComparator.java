package videogames;

import java.util.Comparator;
import videogames.data.VideoGame;

public class VideoGameComparator implements Comparator<VideoGame>
{    

    @Override
    public int compare(VideoGame v1, VideoGame v2) 
    {
        return v1.getTitle().compareTo(v2.getTitle());
    }
}
