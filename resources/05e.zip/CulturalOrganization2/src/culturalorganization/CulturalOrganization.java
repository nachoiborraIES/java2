package culturalorganization;

import culturalorganization.data.Book;
import culturalorganization.data.CulturalObject;
import culturalorganization.data.Loan;
import culturalorganization.data.MusicDisc;
import culturalorganization.data.User;
import java.util.Date;

public class CulturalOrganization 
{
    public static void main(String[] args) 
    {
        CulturalObject[] objects = new CulturalObject[5];
        objects[0] = new Book(200, 1, "Ender's game", "Orson Scott Card");
        objects[1] = new MusicDisc("AAA", 2, "Crossroad", "Bon Jovi");

        for(CulturalObject o: objects)
        {
            System.out.println(o);
        }
        
        User u = new User("1111111A", "Nacho");
        Loan l = new Loan(new Date(), new Date(), objects[0]);
        u.addLoan(l);
    }
    
}
