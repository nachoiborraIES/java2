package culturalorganization.data;

import java.util.Date;

public class Loan 
{
    private Date startDate;
    private Date endDate;
    private CulturalObject object;

    public Loan(Date startDate, Date endDate, CulturalObject object) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.object = object;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public CulturalObject getObject() {
        return object;
    }
}
