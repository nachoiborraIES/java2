package culturalorganization.data;

public class User 
{
    private String id;
    private String name;
    private Loan[] loans;

    public User(String id, String name) {
        this.id = id;
        this.name = name;
        this.loans = new Loan[5];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void addLoan(Loan loan) {
        System.out.println("Adding loan");
    }
    
    public void removeLoan(int position) {
        System.out.println("Removing loan");
    }
    
    public Loan[] getLoans() {
        return loans;
    }
    

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", name=" + name + '}';
    }
}
