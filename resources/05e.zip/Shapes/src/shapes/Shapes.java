package shapes;

import shapes.types.Circle;
import shapes.types.Rectangle;
import shapes.types.Shape;
import shapes.types.Square;

public class Shapes 
{
    public static void main(String[] args) 
    {
        Shape[] shapes = new Shape[3];
        
        shapes[0] = new Circle(10);
        shapes[1] = new Square(4);
        shapes[2] = new Rectangle(3, 8);
        
        for(Shape s: shapes)
        {
            System.out.println(s.calculateArea());
        }
    }    
}
