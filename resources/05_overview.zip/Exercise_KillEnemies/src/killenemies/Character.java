package killenemies;

public interface Character {
	public boolean isEnemy();
}
