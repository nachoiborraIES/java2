/**
 * Program to check some arithmetic operations
 */ 

import java.util.Scanner;

public class CheckOperations
{
    public static void main(String[] args)
    {
        int result = 4 + 8 * 2 / 4;
        System.out.println(result);
        
        result = (4 + 8) * 2 / 4;
        System.out.println(result);
        
        result = (4 + 8) * 3 % 5;
        System.out.println(result);
    }
}
