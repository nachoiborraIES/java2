package animals.types;

public abstract class Animal 
{
    String color;
    int numberOfLegs;

    public Animal(String color, int numberOfLegs) {
        this.color = color;
        this.numberOfLegs = numberOfLegs;
    }

    public String getColor() {
        return color;
    }

    public int getNumberOfLegs() {
        return numberOfLegs;
    }
    
    public abstract void talk();
}
