package animals.main;

import animals.types.Animal;
import animals.types.Bird;
import animals.types.Dog;
import animals.types.Duck;

public class Animals 
{
    public static void main(String[] args) 
    {
        Animal[] animals = new Animal[3];
        animals[0] = AnimalFactory.getAnimal(AnimalType.DOG, "white", 4);
        animals[1] = AnimalFactory.getAnimal(AnimalType.DOG, "black", 4);
        animals[2] = AnimalFactory.getAnimal(AnimalType.DUCK, "pink", 2);
        
        for (Animal a: animals)
        {
            a.talk();
        }
    }
    
}
