package animals.main;

import animals.types.Animal;
import animals.types.Dog;
import animals.types.Duck;

public class AnimalFactory {

    public static Animal getAnimal(AnimalType type, String color, int numberOfLegs)
    {
        if (type == AnimalType.DOG)
        {
            return new Dog(color, numberOfLegs);
        } else if (type == AnimalType.DUCK) {
            return new Duck(color, numberOfLegs);
        } else {
            return null;
        }
    }
    
}
