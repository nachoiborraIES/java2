package animals.main;

public enum AnimalType { DOG, DUCK }
