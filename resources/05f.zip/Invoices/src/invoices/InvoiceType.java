package invoices;

public enum InvoiceType { NORMAL, REDUCED, SUPER }
