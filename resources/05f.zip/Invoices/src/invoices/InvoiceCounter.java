package invoices;

public class InvoiceCounter
{
    private int counter;

    // Static instance of the class
    private static InvoiceCounter myCounter;

    // Private constructor
    private InvoiceCounter()
    {
        this.counter = 0;
    }

    // Static method to manage the single instance
    public static InvoiceCounter getInvoiceCounter()
    {
        if(myCounter == null)
        {
            // Instance has not been create. Use private constructor
            myCounter = new InvoiceCounter();
        }
        // Instance already exists. Return it
        return myCounter;
    }

    public void increaseCounter()
    {
        counter++;
    }

    public int getCounter()
    {
        return counter;
    }
}
