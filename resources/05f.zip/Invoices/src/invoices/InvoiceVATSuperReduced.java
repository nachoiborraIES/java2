package invoices;

public class InvoiceVATSuperReduced extends Invoice {

    @Override
    public double getAmountVAT() {
        return getAmount() * 1.04;
    }
    
}
