package invoices;

public class InvoiceFactory {

    public static Invoice getInvoice(InvoiceType type) {
        if (type == InvoiceType.NORMAL) {
            return new InvoiceVAT();
        } else if (type == InvoiceType.REDUCED) {
            return new InvoiceVATReduced();
        } else if (type == InvoiceType.SUPER) {
            return new InvoiceVATSuperReduced();
        } else {
            return null;
        }
    }
}
