package invoices;

public class Invoices {

    public static void main(String[] args) {
        
        Invoice myInvoice = InvoiceFactory.getInvoice(InvoiceType.NORMAL);
        Invoice myInvoiceRed = InvoiceFactory.getInvoice(InvoiceType.REDUCED);
        Invoice myInvoiceSuper = InvoiceFactory.getInvoice(InvoiceType.SUPER);

        myInvoice.setAmount(1000);
        myInvoiceRed.setAmount(500);
        myInvoiceSuper.setAmount(100);

        System.out.println("Normal Invoice id = " + myInvoice.getId());
        System.out.println(myInvoice.getAmountVAT());
        System.out.println("Reduced Invoice id = " + myInvoiceRed.getId());
        System.out.println(myInvoiceRed.getAmountVAT());
        System.out.println("Super Reduced Invoice id = " + myInvoiceSuper.getId());
        System.out.println(myInvoiceSuper.getAmountVAT());
    }
}
