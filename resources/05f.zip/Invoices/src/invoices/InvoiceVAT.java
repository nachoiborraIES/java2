package invoices;

public class InvoiceVAT extends Invoice {

    @Override
    public double getAmountVAT() {
        return getAmount() * 1.21;
    }
}
