package shapes;

public enum ShapeType { CIRCLE, SQUARE, RECTANGLE }
