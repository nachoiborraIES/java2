package shapes;

import shapes.types.Circle;
import shapes.types.Rectangle;
import shapes.types.Square;

public class Shapes 
{
    public static void main(String[] args) 
    {
        Shape[] shapes = new Shape[3];
        
        shapes[0] = ShapeFactory.getShape(ShapeType.CIRCLE, 3, 0);
        shapes[1] = ShapeFactory.getShape(ShapeType.SQUARE, 4, 0);
        shapes[2] = ShapeFactory.getShape(ShapeType.RECTANGLE, 3, 8);
        
        for(Shape s: shapes)
        {
            System.out.println(s.calculateArea());
        }
    }    
}
