package shapes;

public interface Shape 
{
    public float calculateArea();
    public void draw();
}
