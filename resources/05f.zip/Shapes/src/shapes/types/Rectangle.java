package shapes.types;

import shapes.Shape;

public class Rectangle implements Shape
{
    float base, height;

    public Rectangle(float base, float height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public float calculateArea() {
        return base * height;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a rectangle...");
    }    
}
