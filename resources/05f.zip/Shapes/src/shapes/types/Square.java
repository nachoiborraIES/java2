package shapes.types;

import shapes.Shape;

public class Square implements Shape
{
    float side;

    public Square(float side) {
        this.side = side;
    }

    @Override
    public float calculateArea() {
        return side * side;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a square...");
    }
    
    
}
