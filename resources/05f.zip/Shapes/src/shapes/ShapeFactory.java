package shapes;

import shapes.types.Circle;
import shapes.types.Rectangle;
import shapes.types.Square;

public class ShapeFactory {

    public static Shape getShape(ShapeType type, float param1, float param2)
    {
        if(type == ShapeType.CIRCLE){
            return new Circle(param1);
        } else if(type == ShapeType.RECTANGLE){
            return new Rectangle(param1,param2);
        } else if(type == ShapeType.SQUARE){
            return new Square(param1);
        }

        return null;
    }
}
