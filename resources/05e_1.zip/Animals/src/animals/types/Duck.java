package animals.types;

public class Duck extends Bird
{
    public Duck(String color, int numberOfLegs) {
        super(color, numberOfLegs);
    }

    @Override
    public void fly() {
        System.out.println("I'm flying like a duck!");
    }

    @Override
    public void talk() {
        System.out.println("Quack quack!");
    }   
}
