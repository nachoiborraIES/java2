package animals.types;

public class Dog extends Animal
{
    public Dog(String color, int numberOfLegs) {
        super(color, numberOfLegs);
    }

    @Override
    public void talk() {
        System.out.println("Woof woof!");
    }    
}
