package animals.types;

public abstract class Bird extends Animal
{

    public Bird(String color, int numberOfLegs) {
        super(color, numberOfLegs);
    }
    
    public abstract void fly();
}
