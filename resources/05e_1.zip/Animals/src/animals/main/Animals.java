package animals.main;

import animals.types.Animal;
import animals.types.Bird;
import animals.types.Dog;
import animals.types.Duck;

public class Animals 
{
    public static void main(String[] args) 
    {
        Animal[] animals = new Animal[4];
        
        animals[0] = new Dog("Brown", 4);
        animals[1] = new Duck("White", 2);
        animals[2] = new Duck("Red", 2);
        animals[3] = new Dog("Black", 4);
        
        for (Animal a: animals)
        {
            if (a instanceof Bird)
                ((Bird)a).fly();
        }
    }
    
}
