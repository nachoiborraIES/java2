package shapes.types;

public class Rectangle implements Shape
{
    int base, height;

    public Rectangle(int base, int height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public float calculateArea() {
        return base * height;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a rectangle...");
    }    
}
