package shapes.types;

public class Circle implements Shape
{
    float radius;

    public Circle(float radius) {
        this.radius = radius;
    }

    @Override
    public float calculateArea() {
        return (float)(Math.PI * radius * radius);
    }

    @Override
    public void draw() {
        System.out.println("Drawing a circle...");
    }   
}
