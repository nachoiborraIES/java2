/**
 * Program that checks if a sentence written in LISP programming
 * language is correct, this is, it has the same number of opening
 * and closing brackets. Besides, we must check that no bracket is 
 * closed before its opening
 */ 

import java.util.Scanner;

public class LispChecker
{
    public static void main(String[] args)
    {
        String lispText;
        int index = 0, brackets = 0;
        boolean ok = true;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter LISP text:");
        lispText = sc.nextLine();
        
        while(index < lispText.length() && ok)
        {
            if(lispText.charAt(index) == '(')
                brackets++;
            else if(lispText.charAt(index) == ')')
                brackets--;  
   
			// If brackets < 0, then we have closed a bracket without
			// opening it before
            if (brackets < 0)
                ok = false;
            
            index++;
        }
        
        if (brackets == 0 && ok)
            System.out.println("OK");
        else
            System.out.println("Error");
        
    }
}
