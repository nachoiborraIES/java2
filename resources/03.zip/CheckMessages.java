/**
 * Program that asks the user to enter 10 phrases, then it replaces
 * "Eclipse" with "NetBeans" in every phrase that contains this text.
 * Finally, it prints the replaced phrases
 */ 

import java.util.Scanner;

public class CheckMessages
{
    static final int SIZE = 10;
    
    public static void main(String[] args)
    {
        String[] texts = new String[SIZE];
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter 10 texts:");
        
        for(int i = 0; i < SIZE; i++)
        {
            texts[i] = sc.nextLine();
        }
        
        for(int i = 0; i < SIZE; i++)
        {
            if (texts[i].contains("Eclipse"))
                texts[i] = texts[i].replace("Eclipse", "NetBeans");

            System.out.println(texts[i]);
        }
    }
}
