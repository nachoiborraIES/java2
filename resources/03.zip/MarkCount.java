/**
 * Program that asks the user to enter 10 marks, and then it shows 
 * how many marks of each category (from 0 to 10, inclusive) have been
 * typed
 * 
 * We show here 3 possible solutions to this exercise, depending on
 * which array(s) we want to use
 */ 

import java.util.Scanner;

public class MarkCount
{
    /* Solution 1
     * 
     * We use an array to store the marks, and another array to store
     * the count of each mark
   
    public static void main(String[] args)
    {
        int[] marks, markCounter;
        Scanner sc = new Scanner(System.in);
        
        marks = new int[10];
        markCounter = new int[11];
        
        System.out.println("Enter 10 marks:");
        for(int i = 0; i < marks.length; i++)
        {
            marks[i] = sc.nextInt();
        }
        
        for(int i = 0; i < marks.length; i++)
        {            
            markCounter[marks[i]]++;
        }
        
        for(int i = 0; i < markCounter.length; i++)
        {
            System.out.println(i + ": " + markCounter[i] + " marks");
        }
    }
    */
    
    /* Solution 2
     * 
     * We use just an array to store the marks, and then we use a nested
     * for to explore the marks from 0 to 10 and see how many times they
     * appear in the array
     * 
    public static void main(String[] args)
    {
        int[] marks;
        Scanner sc = new Scanner(System.in);
        
        marks = new int[10];
        
        System.out.println("Enter 10 marks:");
        for(int i = 0; i < marks.length; i++)
        {
            marks[i] = sc.nextInt();
        }
        
        for (int i = 0; i <= 10; i++)
        {
            int counter = 0;
            for (int j = 0; j < marks.length; j++)
            {
                if (marks[j] == i)
                    counter++;
            }
            System.out.println(i + ": " + counter + " marks");
        }
        
    }
    */
    
    /* Solution 3
     * 
     * We just use the array of counters, and every time the user types
     * a new mark, we just increase the counter of the corresponding
     * mark
     */ 
    
    public static void main(String[] args)
    {
        int[] markCounter;
        Scanner sc = new Scanner(System.in);
        
        markCounter = new int[11];
        
        System.out.println("Enter 10 marks:");
        for(int i = 0; i < 10; i++)
        {
            int mark = sc.nextInt();
            markCounter[mark]++;
        }
        
        for(int i = 0; i <= 10; i++)
        {
            System.out.println(i + ": " + markCounter[i] + " marks");
        }
        
    } 
}
