/**
 * Program that asks the user to enter a pair of 3x3 matrices and then
 * it calculates the sum of them.
 */ 

import java.util.Scanner;

public class MatrixAddition
{
    static final int MATRIX_SIZE = 3;
    
    public static void main(String[] args)
    {
        int[][] matrixA, matrixB, matrixResult;
        
        Scanner sc = new Scanner(System.in);
        
        matrixA = new int[MATRIX_SIZE][MATRIX_SIZE];
        matrixB = new int[MATRIX_SIZE][MATRIX_SIZE];
        matrixResult = new int[MATRIX_SIZE][MATRIX_SIZE];
        
        System.out.println("Matrix A:");
        
        for (int i = 0; i < matrixA.length; i++)
        {
            for (int j = 0; j < matrixA[i].length; j++)
            {
                System.out.println("Enter row " + (i + 1) +  
                ", column " + (j + 1));
                matrixA[i][j] = sc.nextInt();
            }
        }

        System.out.println("Matrix B:");
        
        for (int i = 0; i < matrixB.length; i++)
        {
            for (int j = 0; j < matrixB[i].length; j++)
            {
                System.out.println("Enter row " + (i + 1) +  
                ", column " + (j + 1));
                matrixB[i][j] = sc.nextInt();
            }
        }
        
        for (int i = 0; i < matrixResult.length; i++)
        {
            for (int j = 0; j < matrixResult[i].length; j++)
            {
                matrixResult[i][j] = matrixA[i][j] + matrixB[i][j];
            }
        }
        
        System.out.println("Result:");
        
        for (int i = 0; i < matrixResult.length; i++)
        {
            for (int j = 0; j < matrixResult[i].length; j++)
            {
                System.out.print(matrixResult[i][j] + " ");
            }
            
            System.out.println();
        }
        
        
        
    }
}
