package concertattendance;

import java.util.*;

/**
 * This program asks the user to enter people attending to a concert,
 * stores them in a queue and filters only adult people
 */
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        LinkedList<Person> people = new LinkedList<>();
        String name;
        int age;

        System.out.println("Enter name and age of people attending the concert. Type empty name to finish.");
        do
        {
            System.out.println("Name:");
            name = sc.nextLine();
            if (!name.equals(""))
            {
                System.out.println("Age:");
                age = sc.nextInt();
                sc.nextLine();
                people.add(new Person(name, age));
            }
        }
        while(!name.equals(""));

        // Explore queue and discard young people

        while(!people.isEmpty())
        {
            Person p = people.poll();
            if (p.getAge() >= 18)
            {
                System.out.println(p);
            }
        }
    }
}
