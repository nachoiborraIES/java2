package reversedfigure;

import java.util.*;

/**
 * This program asks the user to draw a bi-dimensional figure (line by line)
 * and prints it reversed
 */
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Stack<String> lines = new Stack<>();
        String line;

        System.out.println("Print the lines of the figure. Empty line to finish");

        do
        {
            line = sc.nextLine();
            if (!line.equals(""))
            {
                lines.push(line);
            }
        }
        while(!line.equals(""));

        // Pop items and reverse figure

        while(!lines.empty())
        {
            System.out.println(lines.pop());
        }
    }
}
