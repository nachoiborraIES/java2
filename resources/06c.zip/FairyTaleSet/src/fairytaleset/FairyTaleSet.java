package fairytaleset;

import java.util.*;

public class FairyTaleSet 
{
    public static void main(String[] args) 
    {
        HashSet<FairyTale> tales = new HashSet<>();
        
        tales.add(new FairyTale("Caperucita Roja", 30));
        tales.add(new FairyTale("Cenicienta", 55));
        tales.add(new FairyTale("Caperucita Roja", 40));
        tales.add(new FairyTale("The lion king", 66));

        Iterator<FairyTale> it = tales.iterator();
        while(it.hasNext())
        {
            System.out.println(it.next());
        }        
    }
}
