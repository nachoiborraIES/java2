package library;

import java.util.*;

public class Library 
{
    public static void main(String[] args) 
    {
        Map<String,Book> books = new HashMap<>();
        
        books.put("1111", new Book("1111", "War of the worlds", "H.G. Wells"));
        books.put("2222", new Book("2222", "Misery", "Stephen King"));
        
        Book anotherBook = new Book("3333", "La tabla de Flandes", "Arturo P. Reverte");
        books.put(anotherBook.getId(), anotherBook);
        
        books.put("3333", new Book("3333", "Cabo Trafalgar", "Arturo P. Reverte"));
        
        for(String key: books.keySet())
        {
            System.out.println(books.get(key));
        }
    }    
}
