package shapes.types;

public interface Shape 
{
    public float calculateArea();
    public void draw();
}
