package shapes.types;

/**
 * We can make this class inherit from Rectangle (a Square if a concrete type of
 * rectangle), so that we can use "calculateArea" method from parent's class and
 * rely on Rectangle's constructor
 */

public class Square extends Rectangle implements Shape
{
    int side;

    public Square(int side)
    {
        // A Square is a Rectangle with the same base and height
        super (side, side);
    }

    // We don't need to override "calculateArea" method. We use it from parent class

    @Override
    public void draw() {
        System.out.println("Drawing a square...");
    }
}
