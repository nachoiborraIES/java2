package shapes;

import shapes.types.Circle;
import shapes.types.Rectangle;
import shapes.types.Shape;
import shapes.types.Square;

import java.util.Arrays;
import java.util.Comparator;

public class Shapes 
{
    public static void main(String[] args) 
    {
        Shape[] shapes = new Shape[4];
        
        shapes[0] = new Circle(10);
        shapes[1] = new Square(4);
        shapes[2] = new Rectangle(3, 8);

        // New anonymous class to represent a diamond

        shapes[3] = new Shape() {

            int shortAxis = 3;
            int longAxis = 5;

            @Override
            public float calculateArea() {
                return shortAxis * longAxis / 2f;
            }

            @Override
            public void draw() {
                System.out.println("I'm a diamond!");
            }
        };

        // Sorting array with an anonymous comparator

        Arrays.sort(shapes, new Comparator<Shape>() {
            @Override
            public int compare(Shape s1, Shape s2) {
                return Float.compare(s2.calculateArea(), s1.calculateArea());
            }
        });
        
        for(Shape s: shapes)
        {
            System.out.println(s.getClass().getName() + ": " + s.calculateArea());
        }
    }    
}
