/*
 * In this exercise, we define a Team class with some attributes,
 * constructor and getters/setters, and then in the main program we
 * create a Team object to show its information
 */ 
import java.util.Scanner;

/*
 * Team class
 */ 
class Team
{
    private String name;
    private int foundationYear;
    
    public Team(String n, int y)
    {
		name = n;
		foundationYear = y;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String n)
    {
        name = n;
    }
    
    public int getFoundationYear()
    {
        return foundationYear;
    }
    
    public void setFoundationYear(int y)
    {
        foundationYear = y;
    }    
}

/*
 * Main class
 */
public class TeamsExample
{    
    public static void main(String[] args)
    {
		Team t = new Team("Java F.C.", 1995);
		
		// This causes an error because name is private
		// System.out.println(t.name);
		
		// This is the correct way of getting team's info
        System.out.println(t.getName());
        System.out.println(t.getFoundationYear());
    }
}


