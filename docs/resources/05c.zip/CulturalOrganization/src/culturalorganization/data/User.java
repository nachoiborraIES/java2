package culturalorganization.data;

/**
 * This class stores the information about every user of the cultural
 * organization. To be more precise, we need to store his id, name, and
 * also the array of current loans (up to 5, according to the requirements)
 */

public class User 
{
    private String id;
    private String name;
    private Loan[] loans;
    // Internal counter to determine how many active loans the user has
    private int numLoans;

    public static final int MAX_LOANS = 5;

    public User(String id, String name) {
        this.id = id;
        this.name = name;
        this.loans = new Loan[MAX_LOANS];
        numLoans = 0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * This method should better return a boolean value
     * indicating if the load has been added to the array or not
     */
    public boolean addLoan(Loan loan) {

        boolean result = false;

        if (numLoans < MAX_LOANS) {
            loans[numLoans] = loan;
            // Set loan's user as well
            loan.setUser(this);
            numLoans++;
            result = true;
        }

        return result;
    }

    /**
     * This method also returns a boolean indicating
     * if the loan at the specified position could be
     * removed.
     */
    public boolean removeLoan(int position) {

        boolean result = false;

        if (position >= 0 && position < numLoans) {
            for (int i = position; i < numLoans; i++) {
                loans[i] = loans[i+1];
            }
			numLoans--;
            result = true;
        }

        return result;
    }
    
    public Loan[] getLoans() {
        return loans;
    }

    public int getNumLoans() {
        return numLoans;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", name=" + name + ", num loans=" + numLoans + "}";
    }
}
