package culturalorganization.data;

/**
 * Class to store every loan. We need to store the start and
 * end dates (we represent them as strings instead of dates)
 * and the object itself. The user also stores an array of his
 * own loans, but we also store here the user who has a particular
 * loan, so that we have a bi-directional association, and we can
 * either retrieve the loans of a given user, or the user of a
 * given loan
 */

public class Loan 
{
    private String startDate;
    private String endDate;
    private CulturalObject object;
    private User user;

    public Loan(String startDate, String endDate, CulturalObject object) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.object = object;
    }

    /**
     * An additional constructor in case we want to specify the user at
     * the beginning, instead of using the "setter"
     */
    public Loan(String startDate, String endDate, CulturalObject object, User user) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.object = object;
        this.user = user;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public CulturalObject getObject() {
        return object;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
