package blog.data;

/**
 * Editor class is a subtype of User class for users who can publish
 * posts. It has a Post array with all the posts published by current
 * editor, and a private counter to store how many posts are actually
 * added to the array.
 */

public class Editor extends User {

    protected Post[] posts;
    private int numPosts;

    private static final int MAX_POSTS = 100;

    public Editor(String login, String password) {
        super(login, password);
        // Initialize the array with a space for up to MAX_POSTS posts
        posts = new Post[MAX_POSTS];
        // Initially, there are no posts in the array
        numPosts = 0;
    }

    /**
     * This method adds a new post to the array and increases the counter
     */
    public void publishPost(Post post)
    {
        if (numPosts < MAX_POSTS)
            posts[numPosts] = post;
        numPosts++;
    }

    public Post[] getPosts() {
        return posts;
    }

    public int getNumPosts() {
        return numPosts;
    }

    @Override
    public String toString() {
        return super.toString() + " Editor{" + "numPosts=" + numPosts + '}';
    }
}
