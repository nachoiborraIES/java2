package blog.data;

/**
 * Administrator class extends from User class to
 * define a specific type of user that can register
 * other users.
 */

public class Administrator extends User {
    
    public Administrator(String login, String password) {
        super(login, password);
    }

    /**
     * This method should store the "user" param in a database
     * or text file. For now, we are going to just print a
     * message in the screen.
     */
    public void registerUser(User user)
    {
        System.out.println("Registering user");
    }
}
