package videogame;

import videogame.character.Bowman;
import videogame.character.Character;
import videogame.character.Citizen;
import videogame.character.Miner;
import videogame.character.Soldier;


public class Main {
	
	public static void main(String[] args)
	{
		Character[] c = new Character[5];
		c[0] = new Character(40, 175, "Male", 100);
		c[1] = new Bowman(33, 156, "Male", 80, "Bow", "Silent", 4);
		c[2] = new Miner(44, 173, "Female", 70, "Axe", "Slow", "Unknown", 12);
		c[3] = new Soldier(35, 164, "Female", 120, "Sword");
		c[4] = new Citizen(60, 160, "Male", 20, "Scissors");
		
		for (int i = 0; i < c.length; i++) {
			System.out.println(c[i]);
		}
	}
}
