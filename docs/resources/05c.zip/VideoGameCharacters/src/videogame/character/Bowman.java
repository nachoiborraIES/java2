package videogame.character;

public class Bowman extends Soldier {
	
	protected String movementType;
	protected int damage;
	
	public Bowman(int age, int height, String genre, int lifeLevel, String weapon, String movementType, int damage) {
		super(age, height, genre, lifeLevel, weapon);
		this.movementType = movementType;
		this.damage = damage;
	}
	public String getMovementType() {
		return movementType;
	}
	public void setMovementType(String movementType) {
		this.movementType = movementType;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
	@Override
	public String toString() {
		return super.toString() + " Bowman [movementType=" + movementType + ", damage=" + damage + "]";
	}
	
	
}
