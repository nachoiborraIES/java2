package ships.data;

public class FishingBoat extends Ship
{
    private String type;

    public FishingBoat(String type, String name, int anchors, String material, int length) {
        super(name, anchors, material, length);
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return super.toString() + " FishingBoat{" + "type=" + type + '}';
    }
    
    
}
