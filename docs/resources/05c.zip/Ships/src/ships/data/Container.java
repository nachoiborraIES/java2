package ships.data;

public class Container extends Ship
{
    private int capacityTEU;

    public Container(int capacityTEU, String name, int anchors, String material, int length) {
        super(name, anchors, material, length);
        this.capacityTEU = capacityTEU;
    }

    public int getCapacityTEU() {
        return capacityTEU;
    }

    public void setCapacityTEU(int capacityTEU) {
        this.capacityTEU = capacityTEU;
    }

    @Override
    public String toString() {
        return super.toString() + " Container{" + "capacityTEU=" + capacityTEU + '}';
    }    
}
