package ships;

import ships.data.BulkCarrier;
import ships.data.Container;
import ships.data.FishingBoat;
import ships.data.Ship;
import ships.data.Tanker;

public class Ships 
{
    public static void main(String[] args) 
    {
        Ship[] ships = new Ship[5];
        ships[0] = new Ship("My ship", 2, "Wood", 200);
        ships[1] = new Container(10, "My container", 3, "Metal", 300);
        ships[2] = new BulkCarrier(50, "My carrier", 1, "Metal", 150);
        ships[3] = new Tanker(true, 100, "My tanker", 2, "Fiberglass", 250);
        ships[4] = new FishingBoat("Artisan", "My boat", 1, "Wood", 100);
        
        for(Ship s: ships)
        {
            System.out.println(s);
        }
    }
}
