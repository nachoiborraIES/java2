/*
 * This program calculates recursively the number of digits of a given number
 * The number is provided from command line to main function
 */
  
public class CountDigitsMain
{
    public static int countDigits(int n)
    {
        // Base case: number has one digit
        if (n < 10)
            return 1;
        // Recursive case: we divide by 10 and increase 1 digit
        else
            return 1 + countDigits(n / 10);
    }
    
    public static void main(String[] args)
    {
        if (args.length > 0)
        {
            int number = Integer.parseInt(args[0]);
            System.out.println(countDigits(number));
        }
        else
            System.out.println("No number has been provided");
    }
}
