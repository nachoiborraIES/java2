public class Palindrome
{
    public static boolean isPalindrome(String text)
    {
        int i, j;
        boolean result;
        
        text = text.toUpperCase();
        text = text.replace(" ", "");
        
        i = 0;
        j = text.length() - 1;
        result = true;
        
        while(i <= j && result)
        {
            if (text.charAt(i) != text.charAt(j))
                result = false;
            i++;
            j--;
        }
        
        return result;
    }
    
    public static void main(String[] args)
    {
        System.out.println(isPalindrome("Hannah"));
        System.out.println(isPalindrome("Too hot to hoot"));
        System.out.println(isPalindrome("Java is the best language"));
    }
}
