/*
 * This program tries to solve a 2nd degree equation given the values of 
 * a, b and c (equation coefficients)
 */
import java.util.Scanner;
  
public class Equation
{    
    public static void main(String[] args)
    {
        int a, b, c;
        double x1, x2, temp;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter value for a:");
        a = sc.nextInt();
        System.out.println("Enter value for b:");
        b = sc.nextInt();
        System.out.println("Enter value for c:");
        c = sc.nextInt();
        
        // If a is 0 it's not a 2nd degree equation
        if (a != 0)
        {        
            // We check if square root can be calculated
            temp = b * b - 4 * a * c;
            if (temp >= 0)
            {
                // Equation has solutions
                x1 = (-b + Math.sqrt(temp)) / (2 * a);
                x2 = (-b - Math.sqrt(temp)) / (2 * a);
                
                System.out.println("x1 = " + x1);
                System.out.println("x2 = " + x2);
            }
            else
            {
                System.out.println("Equation has no real solutions");
            }
        }
        else
        {
            System.out.println("Not valid 2nd degree equation");
        }        
    }
}
