/**
 * Another version of the "GramOunceConverter" exercise in which we
 * ask the user to enter the weight unit, and then, using a swith
 * structure, we determine if we must convert from grams to ounces
 * or vice versa
 */ 

import java.util.Scanner;

public class GramOunceConverter2
{
    static final float GRAMS_OUNCES = 28.3495f;
    
    public static void main(String[] args)
    {
        float weight, result;
        String unit;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter weight:");
        weight = sc.nextFloat();
        
        System.out.println("Enter unit (g or o):");
        unit = sc.next();
        
        switch(unit)
        {
            case "g":
                result = weight / GRAMS_OUNCES;
                System.out.printf("%.2f ounces", result);
                break;
            case "o":
                result = weight * GRAMS_OUNCES;
                System.out.printf("%.2f grams", result);
                break;
            default: 
                System.out.println("Unexpected unit");
        }
    }
}
