/**
 * Program that asks the user to enter an amount of people, and then
 * it determines how many groups of 50, 10 and 1 people can be made
 */ 

import java.util.Scanner;

public class GroupPeople
{
    public static void main(String[] args)
    {
        int people, groups50, groups10, groups1;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter how many people are going to attend the conference:");
        people = sc.nextInt();
        
        groups50 = groups10 = groups1 = 0;
        
        /*
         * We can just substract 50 or 10 people to the total amount
         * as long as we can, and then increment the number of 
         * respective groups
         
        while(people >= 50)
        {
            people -= 50;
            groups50++;
        }
        
        while (people >= 10)
        {
            people -= 10;
            groups10++;
        }
        */
        
        
        /*
         * And we can just divide the total amount into 50, and then 
         * into 10 to determine how many groups can be made of each
         * category
         */
        
        groups50 = people / 50;
        people = people % 50;
        
        groups10 = people / 10;        
        groups1 = people % 10;
        
        System.out.println(groups50 + " groups of 50");
        System.out.println(groups10 + " groups of 10");
        System.out.println(groups1 + " groups of 1");
    }
}
