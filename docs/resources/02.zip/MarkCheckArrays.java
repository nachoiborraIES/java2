/**
 * A version of "MarkCheck" exercise using arrays
 * (Arrays are not seen until Unit 3, but this exercise is a good
 * introduction to how to use them)
 */ 

import java.util.Scanner;

public class MarkCheckArrays
{
    public static void main(String[] args)
    {
        int marks[] = new int[3];
        boolean allGreater, allLower;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter 3 marks:");
        for(int i = 0; i < 3; i++)
        {
            marks[i] = sc.nextInt();
        }
        
        /* We use these two boolean values to determine if all the
         * elements of the array are greater or lower than 4, 
         * respectively */
        
        allGreater = true;
        allLower = true;
        
        for(int i = 0; i < 3; i++)
        {
            if (marks[i] < 4)
                allGreater = false;
            else if (marks[i] >= 4)
                allLower = false;
        }
        
        if (allGreater)
        {
            System.out.println("All marks are greater or equal than 4");
        } else if (allLower) {
            System.out.println("No mark is greater or equal than 4");            
        } else {
            System.out.println("Some marks are not greater or equal than 4");            
        }
        
    }
}
