import java.util.regex.*;
import java.util.Scanner;

/*
 * Program that checks if a car ID is valid (made of 4 digits and 3 letters)
 * We use cardinality symbols in this version
 */ 
public class CarIDCheck2
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String carId;
        
        System.out.println("Enter your car ID:");
        carId = sc.nextLine();
        
        Pattern p = Pattern.compile("^\\d{4}[A-Z]{3}$");
        Matcher m = p.matcher(carId);
        
        if (m.find())
        {
            System.out.println("Your car ID is valid");
        }
        else
        {
            System.out.println("Your car ID is NOT valid");
        }
    }
}
