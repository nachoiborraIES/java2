import java.util.regex.*;
import java.util.*;

/*
 * Program that detects hours in a text, stores them in a list and shows it
 * in ascending order (as texts)
 */ 
public class HourIdentifier
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String text;
        List<String> hours = new ArrayList<>();
        
        System.out.println("Enter a text");
        text = sc.nextLine();
        
        Pattern p = Pattern.compile("(\\d{2}:\\d{2})");
        Matcher m = p.matcher(text);
        
        if (m.find())
        {
            do
            {
                hours.add(m.group());
            }
            while (m.find());
        }
        
        if (hours.size() > 0)
        {
            System.out.println("Hours detected (sorted):");
            Collections.sort(hours);
            for(String hour: hours)
            {
                System.out.println(hour);
            }
        }
        else
        {
            System.out.println("No hours found in text");
        }
    }
}
