import java.util.regex.*;
import java.util.Scanner;

/*
 * Program that checks if a car ID is valid (made of 4 digits and 3 letters)
 */ 
public class CarIDCheck
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String carId;
        
        System.out.println("Enter your car ID:");
        carId = sc.nextLine();
        
        Pattern p = Pattern.compile("^\\d\\d\\d\\d[A-Z][A-Z][A-Z]$");
        Matcher m = p.matcher(carId);
        
        if (m.find())
        {
            System.out.println("Your car ID is valid");
        }
        else
        {
            System.out.println("Your car ID is NOT valid");
        }
    }
}
