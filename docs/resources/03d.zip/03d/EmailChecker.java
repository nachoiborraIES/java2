import java.util.regex.*;
import java.util.Scanner;

/*
 * Program that checks if an e-mail is valid: 
 * alphanumerics + @ + alphanumerics + . + alphanumerics
 */ 
public class EmailChecker
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String email;
        
        System.out.println("Enter your e-mail:");
        email = sc.nextLine();
        
        Pattern p = Pattern.compile("^\\w+@\\w+\\.\\w+$");
        Matcher m = p.matcher(email);
        
        if (m.find())
        {
            System.out.println("Your e-mail is valid");
        }
        else
        {
            System.out.println("Your e-mail is NOT valid");
        }
    }
}
